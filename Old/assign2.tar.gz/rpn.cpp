#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>

using namespace std;


//Stack handling class
class Stack
{
    private:
        //Single stack node structure
        struct StackNode
        {
            int number;
            StackNode *prev; //pointer to the previous stack value
        };
        StackNode *pTop; //top of the stack pointer
        int depth; //current stack depth

    public:
        Stack():pTop(NULL),depth(0) {}
        ~Stack()
        {
            //clean the stack by
            while(depth)
               pop();
        }
        //push element to the stack
        void push(int val)
        {
            StackNode *p=new StackNode; //create new stack node
            p->prev=NULL; //make it top by default
            if(pTop)
               p->prev=pTop; //link to the current top
            pTop=p;
            p->number=val;
            depth++; //increase depth
        }
        //pop single element from the stack
        int pop()
        {
            //throw an exception is stack is empty
            if(!pTop)
               throw "Stack is empty!";
            int val=pTop->number; //value on top of the stack
            StackNode *p=pTop;
            pTop=p->prev; //unlink top and move top to the previous stack element
            depth--;
            delete p;
            return val;
        }
        //return depth of the stack
        int dep() const { return depth; }
};
        

int main( int argc, char** argv )
{
    //get arguments from command line, i.e., yourexec filename
    int result, op1,op2,digit,i;
    char oper;
    char expression[100];
    ifstream input_file;
    Stack stack; //stack for expression

    if(argc==2) 
        input_file.open(argv[1]);
    else 
        exit(0);
    //read expression
    while(input_file >> expression)
    {
        //check if expression is an operation or an operand
	if(isdigit(expression[0]))
        {
            //operand, push it to the stack
	    sscanf(expression,"%d",&digit);
	    printf("reading number %d \n",digit);
            stack.push(digit);
	}
	else 
        {
            //operation, handle it
	    sscanf(expression,"%c",&oper);
	    printf("reading operator %c \n",oper);
            //check that we have enough stack depth to handle it 
	    if(stack.dep()<2) //we can handle it later, by throwing exception from pop() but this is clearer
            {
	       cout << "Wrong number of operations!" << endl;
               return -1;
            } 
            //pop operands from the stack
            int v1=stack.pop();
            int v2=stack.pop();
            //process operation and push the result to the stack
            switch(oper)
            {
                case '+':
                   stack.push(v1+v2);
                   break;
                case '-':
                   stack.push(v1-v2);
                   break;
                case '*':
                   stack.push(v1*v2);
                   break;
                case '/':
                   stack.push(v1/v2);
                   break;
                default:
                   cout <<  "Unknown operation requested!" << endl;
                   return -1;
            }
            
	}
    }
    //check expression validity and display the result
    if(stack.dep()!=1)
       cout << "Wrong number of operands!" << endl;
    else
       cout << "The result is " <<  stack.pop() << endl;
    return 0;
}


